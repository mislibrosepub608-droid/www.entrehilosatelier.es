/* Anchor invisible para el enlace de privacidad desde el formulario */
export default function PrivacyAnchor() {
  return <div id="privacidad" />;
}
