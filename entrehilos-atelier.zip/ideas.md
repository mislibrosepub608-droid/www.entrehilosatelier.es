# Ideas de Diseño — Entrehilos Atelier

## Contexto
Taller artesanal de costura y arreglos de ropa por encargo. El logo es elegante, minimalista, con aguja e hilo y máquina de coser en tono gris carbón sobre fondo crema. El nombre "Entrehilos Atelier" evoca tradición, precisión y artesanía de alta costura.

---

<response>
<text>
## Opción A — "Atelier Parisino" (Artisanal Couture)
**Design Movement:** Art Déco suave + Alta Costura francesa
**Core Principles:** Elegancia contenida, artesanía visible, calidez sin ostentación, jerarquía tipográfica clara
**Color Philosophy:** Crema cálida (#F5F0E8) como base, carbón oscuro (#3D3530) para texto, dorado envejecido (#C4A46B) como acento, rosa polvorienta (#D4A5A5) como toque femenino suave
**Layout Paradigm:** Columnas asimétricas con márgenes generosos; secciones alternas texto-imagen; líneas decorativas finas horizontales como separadores
**Signature Elements:** Líneas finas decorativas tipo "regla de sastre", iniciales E.A. en monograma, textura de lino sutil en fondos
**Interaction Philosophy:** Transiciones lentas y suaves, hover con subrayado elegante, scroll revelador
**Animation:** Fade-in suave al scroll, líneas que se dibujan al entrar en viewport
**Typography System:** Cormorant Garamond (display, serif elegante) + Lato (body, sans-serif limpio)
</text>
<probability>0.08</probability>
</response>

<response>
<text>
## Opción B — "Taller Mediterráneo" (Warm Craft Studio) ← SELECCIONADA
**Design Movement:** Artesanía mediterránea contemporánea — cálida, cercana, profesional
**Core Principles:** Calidez artesanal, claridad funcional, confianza local, feminidad discreta
**Color Philosophy:** Blanco roto (#FAF8F5) como base principal, terracota suave (#C17B5C) como acento primario, verde salvia (#7A9E7E) como acento secundario, carbón (#3A3530) para texto. Paleta que evoca telas naturales, hilo y aguja.
**Layout Paradigm:** Diseño editorial con secciones de ancho completo alternadas; hero con imagen a sangre y texto superpuesto; cards de servicios en grid 3 columnas con borde izquierdo de color
**Signature Elements:** Borde izquierdo de acento en cards, separadores con motivo de hilo/costura SVG, fondos con textura de papel muy sutil
**Interaction Philosophy:** Hover con elevación suave (shadow), botones con transición de relleno de izquierda a derecha, scroll suave
**Animation:** Slide-up al entrar en viewport, stagger en listas de servicios
**Typography System:** Playfair Display (títulos, serif dramático) + Source Sans 3 (cuerpo, legible y moderno)
</text>
<probability>0.09</probability>
</response>

<response>
<text>
## Opción C — "Minimal Couture" (Clean Editorial)
**Design Movement:** Minimalismo editorial escandinavo aplicado a moda
**Core Principles:** Espacio en blanco como lujo, tipografía como decoración, fotografía como protagonista
**Color Philosophy:** Blanco puro, negro absoluto, un único acento en burdeos (#8B2635)
**Layout Paradigm:** Grid de 12 columnas estricto, mucho espacio negativo, imágenes a sangre
**Signature Elements:** Números de sección grandes en outline, líneas verticales como separadores
**Interaction Philosophy:** Cursor personalizado, hover con inversión de color
**Animation:** Transiciones de página tipo cortina
**Typography System:** DM Serif Display + DM Sans
</text>
<probability>0.07</probability>
</response>

---

## DISEÑO SELECCIONADO: Opción B — "Taller Mediterráneo"

### Justificación
El estilo mediterráneo cálido conecta perfectamente con un taller local y artesanal. La paleta terracota + salvia + blanco roto transmite confianza, calidez y profesionalidad sin resultar frío ni corporativo. Playfair Display aporta elegancia sin pretensión.

### Tokens de Diseño
- **Background:** #FAF8F5 (blanco roto cálido)
- **Primary:** Terracota #C17B5C → oklch(0.62 0.10 42)
- **Secondary:** Verde salvia #7A9E7E → oklch(0.64 0.07 152)
- **Text:** Carbón #3A3530 → oklch(0.28 0.01 55)
- **Fonts:** Playfair Display (headings) + Source Sans 3 (body)
